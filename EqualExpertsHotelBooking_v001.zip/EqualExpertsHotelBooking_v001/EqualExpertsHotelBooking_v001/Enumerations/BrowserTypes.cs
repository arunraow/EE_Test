﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqualExpertsHotelBooking_v001.Enumerations
{
        public enum BrowserTypes
        {
             
            CHROME
            //Others can be added as required
        }

}
