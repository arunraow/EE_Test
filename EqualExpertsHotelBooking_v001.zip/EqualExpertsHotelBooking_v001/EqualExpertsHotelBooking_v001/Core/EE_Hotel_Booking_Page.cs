﻿using EqualExpertsHotelBooking_v001.Properties;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;


///<summary>
/// This Class Provides the Core Implementation Methods which feed into the Test Step Definitions.
/// Also,this file ensures the Web Elements Data/Implementaion is isolated from the BDD Test Pattern 
/// makes it a scalable pattern to derive similar Test Frameworks .
///</summary> 
///
namespace EqualExpertsHotelBooking_v001.Core
{
    class EE_Hotel_Booking_Page
    {
        //
        private IWebDriver _driver;

        private IWebElement _txtFirstName => _driver.FindElement(By.Id("firstname"));
        private IWebElement _txtLastName => _driver.FindElement(By.Id("lastname"));
        private IWebElement _txtTotalPrice => _driver.FindElement(By.Id("totalprice"));
        private IWebElement _ddlDepositPaid => _driver.FindElement(By.Id("depositpaid"));
        private IWebElement _dpcheckin => _driver.FindElement(By.Id("checkin"));
        private IWebElement _dpcheckout => _driver.FindElement(By.Id("checkout"));

        private By _bookingcount = By.XPath("//*[@id='bookings']/*[@class='row']/following-sibling::div");

        private By _save = By.XPath("//input[contains(@value,' Save ')]");

        ///<summary>
        ///Primary Method which assigns the Web Driver Instance to this Class
        ///</summary>
       
        public EE_Hotel_Booking_Page(IWebDriver driver)
        {
            _driver = driver;
        }

        ///<summary>
        ///Navigate to the Equal Experts Hotel Booking Page
        ///</summary>

        public void EE_Goto_Hotel_Booking_Page()
        {
            _driver.Navigate().GoToUrl(PropertyCollection.Iconfig.GetURL());
            //Need to revisit as the Web Page seems to be taking a while to load and the load time is not consistent
            System.Threading.Thread.Sleep(5000);


        }
        ///<summary>
        ///Enter the Guest Credentials - FirstName and Surname
        ///</summary>

        public EE_Hotel_Booking_Page EE_EnterCredentials(string firstName,string surname)
        {
            _txtFirstName.SendKeys(firstName);
            _txtLastName.SendKeys(surname);

            return this;
        }

        ///<summary>
        ///Private Method - Check-in Date
        ///</summary>

        private void selectCheckin(string checkin)
        {
            _dpcheckin.SendKeys(checkin.ToString());
        }

        ///<summary>
        ///Private Method - Check-Out Date
        ///</summary>
        private void selectCheckout(string checkout)
        {
            _dpcheckout.SendKeys(checkout.ToString());
        }

        ///<summary>
        ///Private Method - Extract Bookings Done so far .This method taps into the Dynamic Div Block that is created/updated every
        ///time a new Entry in registered into the Hotel Database
        ///</summary>
        private int PreviousBookings(string message)
        {
            //The store the list using the collection IList
            IList<IWebElement> BookingRows = _driver.FindElements(_bookingcount);
            //Assign the count of the varibale numberOfBookingRows 
            int numberOfBookingRows = BookingRows.Count;
            Console.WriteLine(message + " " + numberOfBookingRows);
            return numberOfBookingRows;
        }

        ///<summary>
        ///Private Method - Critical Method since the Hotel Booking takes a while to get updated proabably in the 
        ///Database as well as the Web Page.
        ///</summary>

        private bool WaitForNewBookingToBeReflected(int bookingCount)
        {
            
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(60))
            {
                PollingInterval = TimeSpan.FromMilliseconds(5000),
                Timeout = TimeSpan.FromSeconds(40)
            };
            try
            {
                //Wait for the new Booking to come up
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath("//*[@id='bookings']/*[@class='row']/following-sibling::div[position()=" + bookingCount + "]")));

                //Pull out details of CUrrent Booking
                var newBooking = _driver.FindElement(By.XPath("//*[@id='bookings']/*[@class='row']/following-sibling::div[position()=" + bookingCount + "]")).GetAttribute("id");

                //Ensure the Delete Button comes up
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible((By.XPath("//input[@onclick='deleteBooking(" + newBooking + ")']"))));
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine(e.Message);
                return false;//Failure
            }
            return true;//Success
        }

        ///<summary>
        ///Private Method - Critical Method used for deleting an Entry from the Hotel Booking  
        ///Database as well as the Web Page.
        ///</summary>
        private bool WaitForDeleteButtonToBeReflectedAndDeleteit(int bookingCount)
        {

            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(60))
            {
                PollingInterval = TimeSpan.FromMilliseconds(5000),
                Timeout = TimeSpan.FromSeconds(40)
            };
            try
            {
                //Wait for the new Booking to come up
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(By.XPath("//div[@id='bookings']/div[" + bookingCount + "]//input[@value='Delete']"))).Click();
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine(e.Message);
                return false;//Failure
            }
            return true;//Success
        }

        ///<summary>
        ///Private Method - Method to Click on the Save Button used to Create/Append an Entry to the Hotel Booking 
        ///Database as well as the Web Page.
        ///</summary>
        private void ClickOnSave()
        {

            IWebElement saveBtn = _driver.FindElement(_save);
            saveBtn.Click();

        }

        ///<summary>
        ///This method feeds into the Scenario Step Definition File
        ///Method to Update the Pricing Details to the Price and the Deposit Paid Webelements 
        ///</summary>
        public EE_Hotel_Booking_Page EnterPricingDetails(string totalprice, string depositPaid)
        {
            float _price;
            if (float.TryParse(totalprice, out _price) != true)
            {
                Console.WriteLine("Invalid Price Format");
                throw new Exception("Invalid Price Format");
            }
            else
            {
                _txtTotalPrice.SendKeys(totalprice.ToString());
            }

            if (depositPaid.Equals("true"))
                new SelectElement(_ddlDepositPaid).SelectByText("true");
            else
                new SelectElement(_ddlDepositPaid).SelectByText("false");

            return this;
        }

 
        ///<summary>
        ///This method feeds into the Scenario Step Definition File
        ///Method to Enter the Duration of Stay
        ///Check-in and Check-out Dates
        ///NOTE - This method has critical checks to ensure the below :
        ///A> Check-in and Check-out Dates are in either Current Dates or in the Future
        ///B> Check-out date is later than or equal to the CHeck-In Date but not before 
        ///</summary>
        public EE_Hotel_Booking_Page EnterDurationOfStay(string checkInDate,string checkOutDate)
        {
            DateTime _checkin, _checkout;
            _checkin = Convert.ToDateTime(checkInDate);
            _checkout = Convert.ToDateTime(checkOutDate);
            int check1, check2;
            check1 = DateTime.Compare(_checkin, DateTime.Now);
            check2 = DateTime.Compare(_checkin, DateTime.Now);
            
            //CHeck if dates occur in the past
            if (check1 < 0 || check2 < 0)
            {
                Console.WriteLine("Invalid Date combination .Dates occur in the past.Cannot proceed with Booking");
                throw new Exception("Invalid Date combination .Dates occur in the past.Cannot proceed with Booking");
            }
            //Check if the Checkin date is later than the Checkout date
            int _checkoutDateCheck = DateTime.Compare(_checkout, _checkin);
            if (_checkoutDateCheck >= 0)
            { 
                selectCheckin(checkInDate);
                selectCheckout(checkOutDate);
            }else
            {
                Console.WriteLine("Invalid Date combination .Checkout Date before Checkin Date.Cannot proceed with Booking");
                throw new Exception("Invalid Date combination .Checkout Date before Checkin Date.Cannot proceed with Booking");
            }

            return this;
        }

        ///<summary>
        ///This method feeds into the Scenario Step Definition File
        ///Method to Complete and Confirm the Booking Details
        ///</summary>
        public EE_Hotel_Booking_Page CompleteAndConfirmBooking()
        {
            //Get the number of Previous Bookings
            int _previousBookings = PreviousBookings("Fetch Bookings prior to Saving the New One");
            int _newBookings= _previousBookings;//Assign same value as previous Booking

            //Save New Booking
            ClickOnSave();
            //Wait for the new Booking to be refelcted
            if (WaitForNewBookingToBeReflected(_previousBookings + 1) ) //NOTE - This method should check for 1 Booking more than CUrrent Bookings
            {
                _newBookings = PreviousBookings("Fetch Bookings After  Saving the New One");
            }
            if (_newBookings <= _previousBookings)
            {
                Console.WriteLine("Issue in Adding new Booking");
                throw new Exception("Issue in Adding new Booking");
            }
            else
            {
                Console.WriteLine("!!!!!!!!! SCENARIO HAS SUCCESSFULLY BEEN EXECUTED !!!!!!!!!");
            }
            return this;
        }

        ///<summary>
        ///This method feeds into the Scenario Step Definition File
        ///Method to Complete and Confirm the Booking Details
        ///</summary>
        public EE_Hotel_Booking_Page DeleteBooking()
        {
            //Get the number of Previous Bookings
            int _newBookings = PreviousBookings("Fetch Bookings prior to before deleting");
            

            if (WaitForDeleteButtonToBeReflectedAndDeleteit(_newBookings+1) == true)//NOTE : The Delete Button DIV ID's start from Div[2]
            {
                _driver.Navigate().Refresh();
                Console.WriteLine("!!!!!!!!! SCENARIO HAS SUCCESSFULLY BEEN EXECUTED !!!!!!!!!");
            }else
            {
                Console.WriteLine("!!!!!!!!! SCENARIO HAS FAILED !!!!!!!!!");
            }
            return this;

        }

    }
}
