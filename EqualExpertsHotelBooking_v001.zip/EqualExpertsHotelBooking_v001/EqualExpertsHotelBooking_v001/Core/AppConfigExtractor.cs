﻿using EqualExpertsHotelBooking_v001.Enumerations;
using EqualExpertsHotelBooking_v001.Interfaces;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

///<summary>
/// Intent of this file is to Extract the Application Specific Configuration parameters
/// Specifically BROWSER TYPE,URL to be Launched
/// Additonally with VS2019 and beyond - the App.Config will go away and hence the Config.json  
/// Parameter extraction can easily be integrated here.
///</summary> 

namespace EqualExpertsHotelBooking_v001.Core
{
    class AppConfigExtractor: IConfigMgr
    {
        //Returns the browser based on the app config file value compares this to the enum.
        public BrowserTypes GetBrowser()
        {

            return (BrowserTypes)Enum.Parse(typeof(BrowserTypes), ConfigurationManager.AppSettings["Browser"]);
        }


        //Returns the application url based on the value in the app config file.
        public string GetURL()
        {
            return ConfigurationManager.AppSettings["seleniumBaseUrl"];
        }
    }
}
