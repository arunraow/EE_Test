﻿using TechTalk.SpecFlow;
using EqualExpertsHotelBooking_v001.Properties;

namespace EqualExpertsHotelBooking_v001.Steps
{
    [Binding]
    class EE_Hotel_Booking_Step_Defns
    {

        [Given("I am on the hotel booking form")]
        public void GivenIAmOnTheHotelBookingForm()
        {
            PropertyCollection.EEPage = new Core.EE_Hotel_Booking_Page(PropertyCollection.driver);
            PropertyCollection.EEPage.EE_Goto_Hotel_Booking_Page();
            

        }

        [When(@"I enter a(.*) and (.*)credentials")]
        public void WhenIEnterFirstNameAndSurNameCredentials(string firstName,string SurName)
        {
            PropertyCollection.EEPage.EE_EnterCredentials(firstName, SurName);
        }

        [When(@"I provide the pricing details of (.*) and (.*)")]
        public void WhenIProvideThePricingDetailsOfPriceAndDeposit(string price,string deposit)
        {
            PropertyCollection.EEPage.EnterPricingDetails(price, deposit);
        }

        [When(@"I enter the (.*) and (.*) Dates")]
        public void WhenIEnterTheAndDates(string checkinDate,string checkoutDate)
        {
            PropertyCollection.EEPage.EnterDurationOfStay(checkinDate, checkoutDate);
        }

        [Then("I press the save button to check for the booking completion")]
        public void IPressTheSaveButtonToCheckForTheBookingCompletion()
        {
            PropertyCollection.EEPage.CompleteAndConfirmBooking();
        }

        [Then("I Save the Booking and Delete it")]
        public void ISavetheBookingandDeleteit()
        {
            PropertyCollection.EEPage.CompleteAndConfirmBooking();
            
            PropertyCollection.EEPage.DeleteBooking();
        }

    }
}
