﻿using EqualExpertsHotelBooking_v001.Core;
using OpenQA.Selenium;
using System.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqualExpertsHotelBooking_v001.Interfaces;

namespace EqualExpertsHotelBooking_v001.Properties
{
    class PropertyCollection
    {

        public static IWebDriver driver { get; set; }
        public static EE_Hotel_Booking_Page EEPage { get; set; }
        public static IConfigMgr Iconfig { get; set; }
    }
}
