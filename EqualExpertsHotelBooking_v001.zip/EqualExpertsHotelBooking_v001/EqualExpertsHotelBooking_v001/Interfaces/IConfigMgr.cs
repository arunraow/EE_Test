﻿using EqualExpertsHotelBooking_v001.Enumerations;


///<summary>
///This Interface  helps define Customised Code to extract the Config Data specific to any Application
///</summary>
namespace EqualExpertsHotelBooking_v001.Interfaces
{
    public interface IConfigMgr
    {
        //Interface methods used by the application configuration reader class to turn these methods into action.
        BrowserTypes GetBrowser();
        string GetURL();
    }
}
