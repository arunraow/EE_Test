﻿using EqualExpertsHotelBooking_v001.Core;
using EqualExpertsHotelBooking_v001.Enumerations;
using EqualExpertsHotelBooking_v001.Properties;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;


///<summary>
///This Class is specific to Specflow[Cucumber] Implementation of Actions to be executed Prior to Post execution of a Scenario
///This would be generally for Setup and Teardown of Scenario related code 
///NOTE - This would be very helpful to handle multiple scenario's in a Single SCENARIO OUTLINE
///SPECFLOW ensures this piece of Code is automatically executed
///</summary>
namespace EqualExpertsHotelBooking_v001.Hooks
{
    [Binding]
    public sealed class Hooks
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

        [BeforeScenario]
        public void Init()
        {
            //TODO: implement logic that has to run before executing each scenario
            PropertyCollection.Iconfig = new AppConfigExtractor();

            switch(PropertyCollection.Iconfig.GetBrowser())
            {
                case BrowserTypes.CHROME:
                    PropertyCollection.driver = new ChromeDriver();
                    break;
                default:
                    throw new Exception("Invalid Driver");
            }
        }

        [AfterScenario]
        public void AfterScenario()
        {
            //TODO: implement logic that has to run after executing each scenario
            
            if (PropertyCollection.driver != null)
            {
                PropertyCollection.driver.Close();
                PropertyCollection.driver.Quit();
            }
            
        }
    }
}
